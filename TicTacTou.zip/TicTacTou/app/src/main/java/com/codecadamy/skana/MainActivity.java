package com.codecadamy.skana;

import androidx.appcompat.app.AppCompatActivity;

import android.graphics.Color;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {


private TextView playerOnescore, playerTwoscore, playerStatus;
private Button[] button = new Button[9];
private Button resetGame;

private int playerOneScoreCount, playerTwoScoreCount, rountCount;
boolean activePlayer;

int [] gameState = {2,2,2,2,2,2,2,2,2};
int [][] winningPositions = {
        {0, 1, 2}, {3,4,5}, {6,7,8},
        {0,3,6}, {1,4,7}, {2,5,8},
        {0,4,8}, {2,4,6}
};


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        playerOnescore =(TextView) findViewById(R.id.playerOneScore);
        playerTwoscore =(TextView) findViewById(R.id.playerTwoscore);
        playerStatus = (TextView) findViewById(R.id.playerStatus);

        resetGame = (Button) findViewById(R.id.resetGame);

        for (int i=0; i < button.length; i++){
            String buttonID = "btn_" + i;
            int resourceID = getResources().getIdentifier(buttonID, "id", getPackageName());
            button[i] = (Button) findViewById(resourceID);
            button[i].setOnClickListener(this);
        }

        rountCount = 0;
        playerOneScoreCount = 0;
        playerTwoScoreCount = 0;
        activePlayer = true;

    }

    @Override
    public void onClick(View v) {

        if (!((Button)v).getText().toString().equals("")){
            return;
        }
        String buttonID = v.getResources().getResourceEntryName(v.getId());
        int gameStatePointer =Integer.parseInt(buttonID.substring(buttonID.length()-1, buttonID.length()));

        if (activePlayer){
            ((Button)v).setText("X");
            ((Button)v).setTextColor(Color.parseColor("#FFC34A"));
            gameState[gameStatePointer] = 0;
        }else {
            ((Button)v).setText("O");
            ((Button)v).setTextColor(Color.parseColor("#70FFEA"));
            gameState[gameStatePointer] = 1;

        }
        rountCount++;

        if (checkWinner()){
            if (activePlayer){
                playerOneScoreCount++;
                updatePlayerScore();
                Toast.makeText(this, "Pirmais Spēlētājs uzvarējs!", Toast.LENGTH_LONG).show();
                playAgain();

            }else {
                playerTwoScoreCount++;
                updatePlayerScore();
                Toast.makeText(this, "Otrais spēlētājs uzvarējs!", Toast.LENGTH_LONG).show();
                playAgain();

            }

        }else if (rountCount == 9){
            playAgain();
            Toast.makeText(this, "Nav uzvarētāju", Toast.LENGTH_LONG).show();


        }else {
            activePlayer = !activePlayer;
        }
        if (playerOneScoreCount > playerTwoScoreCount){
            playerStatus.setText("Pirmais apēlētājs uzvar");
        } else if (playerTwoScoreCount > playerOneScoreCount){
            playerStatus.setText("Otrais spēlētājs uzvar");
        } else{
            playerStatus.setText("");
        }
        resetGame.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                playAgain();
                playerOneScoreCount = 0;
                playerTwoScoreCount = 0;
                playerStatus.setText("");
                updatePlayerScore();
            }
        });
    }
    public boolean checkWinner(){
        boolean winnerResulte = false;

        for (int [] winningPosion : winningPositions){
            if (gameState[winningPosion[0]] == gameState[winningPosion[1]] && gameState[winningPosion[1]] ==  gameState[winningPosion[2]] && gameState[winningPosion[0]] !=2){

                winnerResulte = true;

            }
        }
        return winnerResulte;

    }
    public void updatePlayerScore(){
        playerOnescore.setText(Integer.toString(playerOneScoreCount));
        playerTwoscore.setText(Integer.toString(playerTwoScoreCount));

    }
    public void playAgain(){
        rountCount = 0;
        activePlayer = true;

        for (int i = 0; i < button.length; i++){
            gameState[i] = 2;
            button[i].setText("");
        }
    }
}